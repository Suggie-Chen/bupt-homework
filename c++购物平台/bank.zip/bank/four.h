﻿#ifndef FOUR_H
#define FOUR_H

#include <QDialog>

namespace Ui {
class four;
}

class four : public QDialog
{
    Q_OBJECT

public:
    explicit four(QString k, QWidget *parent = 0);
    ~four();

private slots:
    void on_pushButton_clicked();

private:
    Ui::four *ui;
};

#endif // FOUR_H
