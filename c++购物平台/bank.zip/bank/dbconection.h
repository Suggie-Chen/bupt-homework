﻿#ifndef DBCONECTION_H
#define DBCONECTION_H
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
static bool createConnection()
{
    QSqlDatabase db1 = QSqlDatabase::addDatabase("QSQLITE");
    db1.setDatabaseName("bank.db");//database name
    if(!db1.open()) return false;//数据库未打开
    QSqlQuery query;
    query.exec("create table banks (id INTEGER primary key,password vchar,bankname vchar,username vchar,userid vchar,money double)");
    return true;

}
#endif // DBCONECTION_H
