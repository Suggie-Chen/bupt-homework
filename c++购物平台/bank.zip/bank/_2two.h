﻿#ifndef _2TWO_H
#define _2TWO_H
#include"dbconection.h"
#include"bank.h"
#include <QDialog>

namespace Ui {
class _2two;
}

class _2two : public QDialog
{
    Q_OBJECT

public:
    explicit _2two(QWidget *parent = 0);
    ~_2two();

private slots:
    void on_pushButton_clicked();

private:
    Ui::_2two *ui;
    bank *sp;
    QSqlDatabase db;
    QSqlQuery *query;
    QSqlTableModel * model;
};

#endif // _2TWO_H
