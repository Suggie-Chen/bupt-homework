﻿#ifndef BANK_H
#define BANK_H
#include<QString>
#include"dbconection.h"
class bank
{
public:

    bank(){}
    bank(int a,QString b, QString c, QString d, QString e ,double f):id(a),password(b),bankname(c),username(d),userid(e),money(f){}
    void UPmoney();
    void setmoney(double);
    //返回私有成员
    int returnid();
    QString returnpassword();
    QString returnbankname();
    QString returnusername();
    QString returnuserid();
    double returnmoney();
private:
    int id;
    QString password;
    QString bankname;
    QString username;
    QString userid;
    double money;
    QSqlDatabase db;//数据库
    QSqlQuery *query;//数据库
};

#endif // BANK_H
