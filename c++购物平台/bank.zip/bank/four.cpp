﻿#include "four.h"
#include "ui_four.h"

four::four(QString k, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::four)
{
    ui->setupUi(this);
    ui->label->setText(k);
}

four::~four()
{
    delete ui;
}

void four::on_pushButton_clicked()
{
    this->close();
}
