﻿#ifndef TWO_H
#define TWO_H
#include<bank.h>
#include <QDialog>

namespace Ui {
class two;
}

class two : public QDialog
{
    Q_OBJECT

public:
    explicit two(bank *s,QWidget *parent = 0);
    ~two();

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::two *ui;
    bank *sp;//指针
    //数据库
    QSqlDatabase db;
    QSqlQuery *query;
};

#endif // TWO_H
