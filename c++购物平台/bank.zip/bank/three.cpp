﻿#include "three.h"
#include "ui_three.h"
#include"four.h"
#include<QDebug>
#include<qsqlerror.h>
three::three(bank *s,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::three)
{
    ui->setupUi(this);
    sp=new bank();
    sp=s;

}

three::~three()
{
    delete ui;
}

void three::on_pushButton_clicked()//修改密码
{
    QString m=ui->lineEdit->text();
    ui->lineEdit->clear();

    if(m!=sp->returnpassword())
    {
        four k("error");
         ui->lineEdit_2->clear();
         ui->lineEdit_3->clear();
        //未修改成功
        k.show();
        k.exec();
    }
    else
    {
        //修改成功
        m=ui->lineEdit_2->text();
        ui->lineEdit_2->clear();
        QString n=ui->lineEdit_3->text();
        ui->lineEdit_3->clear();
        if(m==n&&m.size()==6&&!m.isEmpty())
        {
            db=QSqlDatabase::database("bank.db");
            query=new QSqlQuery(db);
            QString sql_seclet;
            sql_seclet=QString("update banks set password='%1' where id='%2';").arg(m).arg(sp->returnid());
            if(!query->exec(sql_seclet))
            {
                qDebug()<<query->lastError();
            }
            else
            {
                four k("success");
                k.show();
                k.exec();
            }

        }
        else
        {
            four k("error");
            k.show();
            k.exec();
        }

    }
}
