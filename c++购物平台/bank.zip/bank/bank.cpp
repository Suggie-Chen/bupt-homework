﻿#include "bank.h"
#include<QDebug>
#include<QSqlError>
void bank::UPmoney()//取钱
{
    db=QSqlDatabase::database("bank.db");
    query=new QSqlQuery(db);
    QString sql_select;
    sql_select=QString("update banks set money ='%1'where id ='%2' ").arg(this->returnmoney()).arg(this->returnid());
    if(!query->exec(sql_select))
    {
        qDebug()<<"存取钱"<<query->lastError();
    }
    else
    {
        qDebug()<<"success";
    }
}
void bank:: setmoney(double k)//存钱
{
    money=k;
}
QString bank::returnbankname()
{
    return bankname;
}
QString bank::returnpassword()
{
    return password;
}
QString bank::returnusername()
{
    return username;
}

QString bank::returnuserid()
{
    return userid;
}
int bank::returnid()
{
    return id;
}
double bank::returnmoney()
{
    return money;
}
