﻿#include "two.h"
#include "ui_two.h"
#include<QDebug>
#include"three.h"
two::two(bank *s,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::two)
{
    ui->setupUi(this);
   // sp=new bank(s.returnid(),s.returnpassword(),s.returnbankname(),s.returnusername(),s.returnuserid(),s.returnmoney());
    sp=new bank();
    sp=s;
  //  qDebug()<<sp->returnbankname();
   int m=sp->returnid();
   QString m1;
   m1=QString::number(m,10);
   //显示个人信息
   ui->label->setText(sp->returnusername());
   ui->label_8->setText(m1);
   ui->label_9->setText(sp->returnbankname());
   ui->label_10->setText(sp->returnusername());
   ui->label_11->setText(sp->returnuserid());
   double n=sp->returnmoney();
   QString n1;
   n1.setNum(n);
   ui->label_12->setText(n1);
}

two::~two()
{
    delete ui;
}

void two::on_pushButton_3_clicked()
{
    three k(sp);
    k.show();
    k.exec();
}
bool isDigitStr(QString src)
{
QByteArray ba = src.toLatin1();//QString 转换为 char*
const char *s = ba.data();
while(*s && *s>='0' && *s<='9') s++;
if (*s)
{ //不是纯数字
return false;
}
else
{ //纯数字
return true;
}
}
void two::on_pushButton_clicked()//存钱
{
    QString m=ui->doubleSpinBox->text();
    ui->doubleSpinBox->clear();
    double zzz=m.toDouble();
    if(!m.isEmpty()&&zzz!=0)
    {
        double n=m.toDouble();
        if(n<0)
        {
            ui->label_16->setText("输入小于零");
        }
        else {

                sp->setmoney(sp->returnmoney()+n);
                QString n1;
                n1.setNum(sp->returnmoney());
                ui->label_12->setText(n1);
                ui->label_16->setText("success");
                sp->UPmoney();//更新数据库
            }
        }
        else
    {
        ui->label_16->setText("输入错误");
    }
}

void two::on_pushButton_2_clicked()//取钱
{
    QString m=ui->doubleSpinBox->text();
    ui->doubleSpinBox->clear();
    if(!m.isEmpty())
    {
        double n=m.toDouble();
        if(n<0)
        {
            ui->label_16->setText("输入小于零");
        }
        else {
               if(sp->returnmoney()>=n)
               {

                sp->setmoney(sp->returnmoney()-n);
                QString n1;
                n1.setNum(sp->returnmoney());
                ui->label_12->setText(n1);
                ui->label_16->setText("success");
                sp->UPmoney();//更新数据库
               }
               else
               {
                   ui->label_16->setText("余额不足");
               }
            }
        }
        else
    {
        ui->label_16->setText("输入错误");
    }
}

void two::on_pushButton_4_clicked()
{
    this->close();
}

void two::on_pushButton_5_clicked()
{
    this->close();
}
