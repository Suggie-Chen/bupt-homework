/********************************************************************************
** Form generated from reading UI file 'two.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TWO_H
#define UI_TWO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_two
{
public:
    QLabel *label;
    QLabel *label_2;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QLabel *label_3;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_13;
    QDoubleSpinBox *doubleSpinBox;
    QLabel *label_14;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label_15;
    QLabel *label_16;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_3;

    void setupUi(QDialog *two)
    {
        if (two->objectName().isEmpty())
            two->setObjectName(QStringLiteral("two"));
        two->resize(603, 515);
        label = new QLabel(two);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 30, 72, 15));
        label_2 = new QLabel(two);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(130, 30, 72, 15));
        verticalLayoutWidget = new QWidget(two);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(40, 110, 91, 341));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(verticalLayoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout->addWidget(label_4);

        label_3 = new QLabel(verticalLayoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout->addWidget(label_3);

        label_5 = new QLabel(verticalLayoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout->addWidget(label_5);

        label_6 = new QLabel(verticalLayoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        verticalLayout->addWidget(label_6);

        label_7 = new QLabel(verticalLayoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));

        verticalLayout->addWidget(label_7);

        verticalLayoutWidget_2 = new QWidget(two);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(140, 110, 160, 341));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(verticalLayoutWidget_2);
        label_8->setObjectName(QStringLiteral("label_8"));

        verticalLayout_2->addWidget(label_8);

        label_9 = new QLabel(verticalLayoutWidget_2);
        label_9->setObjectName(QStringLiteral("label_9"));

        verticalLayout_2->addWidget(label_9);

        label_10 = new QLabel(verticalLayoutWidget_2);
        label_10->setObjectName(QStringLiteral("label_10"));

        verticalLayout_2->addWidget(label_10);

        label_11 = new QLabel(verticalLayoutWidget_2);
        label_11->setObjectName(QStringLiteral("label_11"));

        verticalLayout_2->addWidget(label_11);

        label_12 = new QLabel(verticalLayoutWidget_2);
        label_12->setObjectName(QStringLiteral("label_12"));

        verticalLayout_2->addWidget(label_12);

        horizontalLayoutWidget = new QWidget(two);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(350, 260, 203, 80));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_13 = new QLabel(horizontalLayoutWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout->addWidget(label_13);

        doubleSpinBox = new QDoubleSpinBox(horizontalLayoutWidget);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        doubleSpinBox->setMaximum(5000.99);

        horizontalLayout->addWidget(doubleSpinBox);

        label_14 = new QLabel(horizontalLayoutWidget);
        label_14->setObjectName(QStringLiteral("label_14"));

        horizontalLayout->addWidget(label_14);

        horizontalLayoutWidget_2 = new QWidget(two);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(350, 340, 203, 80));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(horizontalLayoutWidget_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout_2->addWidget(pushButton);

        pushButton_2 = new QPushButton(horizontalLayoutWidget_2);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout_2->addWidget(pushButton_2);

        label_15 = new QLabel(two);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(130, 80, 72, 15));
        label_16 = new QLabel(two);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(410, 210, 72, 15));
        pushButton_4 = new QPushButton(two);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(650, 480, 93, 28));
        pushButton_5 = new QPushButton(two);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(500, 450, 93, 28));
        pushButton_3 = new QPushButton(two);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(390, 450, 93, 28));

        retranslateUi(two);

        QMetaObject::connectSlotsByName(two);
    } // setupUi

    void retranslateUi(QDialog *two)
    {
        two->setWindowTitle(QApplication::translate("two", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("two", "TextLabel", Q_NULLPTR));
        label_2->setText(QApplication::translate("two", "\346\254\242\350\277\216\345\210\260\346\235\245", Q_NULLPTR));
        label_4->setText(QApplication::translate("two", "\345\215\241\345\217\267\357\274\232", Q_NULLPTR));
        label_3->setText(QApplication::translate("two", "\351\223\266\350\241\214\345\220\215\357\274\232", Q_NULLPTR));
        label_5->setText(QApplication::translate("two", "\345\247\223\345\220\215\357\274\232", Q_NULLPTR));
        label_6->setText(QApplication::translate("two", "\350\272\253\344\273\275\350\257\201\357\274\232", Q_NULLPTR));
        label_7->setText(QApplication::translate("two", "\344\275\231\351\242\235\357\274\232", Q_NULLPTR));
        label_8->setText(QApplication::translate("two", "TextLabel", Q_NULLPTR));
        label_9->setText(QApplication::translate("two", "TextLabel", Q_NULLPTR));
        label_10->setText(QApplication::translate("two", "TextLabel", Q_NULLPTR));
        label_11->setText(QApplication::translate("two", "TextLabel", Q_NULLPTR));
        label_12->setText(QApplication::translate("two", "TextLabel", Q_NULLPTR));
        label_13->setText(QApplication::translate("two", "\351\207\221\351\242\235\357\274\232 ", Q_NULLPTR));
        label_14->setText(QApplication::translate("two", " \345\205\203   ", Q_NULLPTR));
        pushButton->setText(QApplication::translate("two", "\345\255\230\351\222\261", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("two", "\345\217\226\351\222\261", Q_NULLPTR));
        label_15->setText(QApplication::translate("two", "\346\202\250\347\232\204\344\277\241\346\201\257", Q_NULLPTR));
        label_16->setText(QString());
        pushButton_4->setText(QApplication::translate("two", "\346\263\250\351\224\200", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("two", "\346\263\250\351\224\200", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("two", "\344\277\256\346\224\271\345\257\206\347\240\201", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class two: public Ui_two {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TWO_H
