/********************************************************************************
** Form generated from reading UI file '_2two.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI__2TWO_H
#define UI__2TWO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui__2two
{
public:
    QPushButton *pushButton;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_4;
    QLabel *label_6;
    QVBoxLayout *verticalLayout;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_8;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit;
    QLabel *label_7;
    QListView *listView;

    void setupUi(QDialog *_2two)
    {
        if (_2two->objectName().isEmpty())
            _2two->setObjectName(QStringLiteral("_2two"));
        _2two->resize(412, 372);
        pushButton = new QPushButton(_2two);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(180, 280, 93, 28));
        layoutWidget = new QWidget(_2two);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 120, 242, 135));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        lineEdit_4 = new QLineEdit(layoutWidget);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));

        gridLayout->addWidget(lineEdit_4, 8, 1, 1, 1);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout->addWidget(label_6, 9, 1, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout->addWidget(label_3);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout->addWidget(label_2);

        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout->addWidget(label_4);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout->addWidget(label_5);


        gridLayout->addLayout(verticalLayout, 1, 0, 9, 1);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout->addWidget(label_8, 4, 1, 1, 1);

        lineEdit_3 = new QLineEdit(layoutWidget);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        gridLayout->addWidget(lineEdit_3, 6, 1, 1, 1);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        gridLayout->addWidget(lineEdit, 1, 1, 1, 1);

        label_7 = new QLabel(_2two);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(300, 100, 72, 15));
        listView = new QListView(_2two);
        listView->setObjectName(QStringLiteral("listView"));
        listView->setGeometry(QRect(260, 120, 141, 131));

        retranslateUi(_2two);

        QMetaObject::connectSlotsByName(_2two);
    } // setupUi

    void retranslateUi(QDialog *_2two)
    {
        _2two->setWindowTitle(QApplication::translate("_2two", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("_2two", "\346\263\250\345\206\214", Q_NULLPTR));
        label_6->setText(QApplication::translate("_2two", "\345\210\235\345\247\213\344\270\2720\345\205\203", Q_NULLPTR));
        label_3->setText(QApplication::translate("_2two", "\345\257\206\347\240\201", Q_NULLPTR));
        label_2->setText(QApplication::translate("_2two", "\351\223\266\350\241\214\345\220\215", Q_NULLPTR));
        label->setText(QApplication::translate("_2two", "\345\247\223\345\220\215", Q_NULLPTR));
        label_4->setText(QApplication::translate("_2two", "\350\272\253\344\273\275\350\257\201\345\217\267", Q_NULLPTR));
        label_5->setText(QApplication::translate("_2two", "\344\275\231\351\242\235", Q_NULLPTR));
        label_8->setText(QApplication::translate("_2two", "\345\217\263\350\276\271\351\200\211\346\213\251", Q_NULLPTR));
        label_7->setText(QApplication::translate("_2two", "\345\217\257\347\224\250\351\223\266\350\241\214", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class _2two: public Ui__2two {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI__2TWO_H
