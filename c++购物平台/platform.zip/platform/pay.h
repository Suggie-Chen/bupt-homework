﻿#ifndef PAY_H
#define PAY_H

#include <QDialog>
#include <QTcpSocket>
#include"platformuser.h"
namespace Ui {
class pay;
}

class pay : public QDialog
{
    Q_OBJECT

public:
    explicit pay(QString a,double b,QString e,platformuser *s,QWidget *parent = 0);
    ~pay();


private:
    Ui::pay *ui;
    QString c;//银行号
    double d;//保存需要支付的钱
    QString f;//密码

    QTcpSocket *socket;
    platformuser *sp;
    QSqlDatabase db;
    QSqlQuery *query;
    QSqlDatabase db1;
    QSqlQuery *query1;
    QSqlDatabase db2;
    QSqlQuery *query2;
    QSqlDatabase db3;
    QSqlQuery *query3;
    QSqlDatabase db4;
    QSqlQuery *query4;


private slots:
     void socket_Read_Data();
     void socket_Disconnected();
     void socket_pay();
     void on_pushButton_clicked();
     void on_pushButton_2_clicked();
};

#endif // PAY_H
