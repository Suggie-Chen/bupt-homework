﻿#ifndef DISCARD_H
#define DISCARD_H
extern double dmoney;//满多少
extern double kmoney;//减多少
extern double ddiscard1;//书折扣
extern double ddiscard2;//衣服折扣
extern double ddiscard3;//零食折扣
#endif // DISCARD_H
