﻿#include "pay.h"
#include "ui_pay.h"
#include<QSqlError>
#include<QDebug>
#include"ui/two.h"
pay::pay(QString a, double b,QString e, platformuser*s, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::pay)
{
    ui->setupUi(this);
    db3=QSqlDatabase::database("PlatformUsers.db");
    query3=new QSqlQuery(db);
    db4=QSqlDatabase::database("PlatformUsers.db");
    query4=new QSqlQuery(db);
    sp=new platformuser(s->returnid(),s->returnlogname(),s->returnpassword(),s->returnwaitmoney());
    //获得账号金额密码
    c=a;
    d=b;
    f=e;
    ui->pushButton->setText("请等待");
    ui->pushButton->setEnabled(false);
     ui->pushButton_2->setEnabled(false);
    socket = new QTcpSocket();

    //连接信号槽
    socket_pay();

        QObject::connect(socket, &QTcpSocket::readyRead, this, &pay::socket_Read_Data);
        QObject::connect(socket, &QTcpSocket::disconnected, this, &pay::socket_Disconnected);
}

pay::~pay()
{
    delete ui;
}
void pay::socket_Read_Data()
{
    QByteArray buffer;
   //读取缓冲区数据
    buffer = socket->readAll();
    QString str;
    if(!buffer.isEmpty())
    {
      //   str = ui->textEdit->toPlainText();
        str=tr(buffer);
        //刷新显示
        //ui->textEdit->setText(str);
    }
    else
    {
        qDebug()<<"客户端读的是空的";
    }
    if(str=="1")//成功
    {
        db=QSqlDatabase::database("PlatformUsers.db");
        query=new QSqlQuery(db);
        QString sql_select;
        sql_select=QString("update student set waitmoney= 0 where id = '%1'").arg(sp->returnid());
        qDebug()<<"支付成功？";
        qDebug()<<"id？"<<sp->returnid();
        if(!query->exec(sql_select))
        {
            qDebug()<<query->lastError();
            str="";
        }
        else
        {
            QString y;
            ui->label->setText("成功支付");
            sql_select=QString("select * from shoplist where userid='%1'").arg(sp->returnid());
            db1=QSqlDatabase::database("PlatformUsers.db");
            query1=new QSqlQuery(db);
            db2=QSqlDatabase::database("PlatformUsers.db");
            query2=new QSqlQuery(db);
            QString sql_select1;

            int c11;
            if(!query->exec(sql_select))
            {
                qDebug()<<"1"<<query->lastError();
            }
            else
            {
                while(query->next())
                {
                    int a=query->value(4).toInt();
                    QString b=query->value(3).toString();
                    qDebug()<<"A"<<a<<"b"<<b;
                    sql_select1=QString(" select * from goods where name = '%1' ").arg(b);
                    if(!query1->exec(sql_select1))
                    {
                         qDebug()<<"2"<<query1->lastError();
                    }
                    else
                    {
                        if(query1->next())
                        {
                             c11=query1->value(3).toInt();
                        }
                        else
                        {
                            qDebug()<<"mei zhaodao";
                        }
                    }
                    qDebug()<<"到这里了";
                    y=QString("update goods set num= '%1' where name ='%2'").arg(c11-a).arg(b);
                    query2->exec(y);
                }
            }
            QString sql_select2;
            QString sql_select3;
            sql_select2=QString("select *from shoplist where userid = '%1'").arg(sp->returnid());

            if(!query3->exec(sql_select2))
            {
                qDebug()<<query3->lastError();
            }
            else
            {

                while (query3->next())
                {
                        qDebug()<<"holyshit";
                        sql_select3=QString("insert into paylist values(null,'%2','%3','%4','%5','%6','%7','%8')").arg(sp->returnid()).arg(query3->value(2).toString()).arg(query3->value(3).toString()).arg(query3->value(4).toInt()).arg(query3->value(5).toString()).arg(query3->value(6).toDouble()).arg(query3->value(7).toDouble());
                        if(!query4->exec(sql_select3))
                        {
                            qDebug()<<query4->lastError();
                        }
                        else
                        {
                            qDebug()<<"成功放入paylist";
                        }

                }
            }
            sql_select=QString("delete from shoplist where userid= '%1'").arg(sp->returnid());
            if(!query->exec(sql_select))
            {
                qDebug()<<query->lastError();
            }
            {
                ui->pushButton->setText("返回");
                ui->pushButton->setEnabled(true);
               // this->close();
                str="";
            }

        }

    }
    else
    {
        if(str=="0")//钱不够
        {
            ui->label->setText("余钱不够");
            ui->pushButton_2->setText("返回");
            ui->pushButton_2->setEnabled(true);
            //this->close();
            str="";
        }
        if(str=="2")//密码不对
        {
            ui->label->setText("密码不对");
            ui->pushButton_2->setText("返回");
            ui->pushButton_2->setEnabled(true);
            //this->close();
            str="";
        }
    }
}
void pay::socket_pay()
{
    QString IP;
    int port;
    //获取IP地址
    IP = "127.0.0.1";
    //获取端口号
    port = 8086;
    //取消已有的连接
    socket->abort();
    //连接服务器
    socket->connectToHost(IP, port);
    //等待连接成功
    if(!socket->waitForConnected(30000))
    {
        qDebug() << "Connection failed!";
        return;
    }
    else
    {
        qDebug() << "Connect successfully!";
        QString flagdate="@";
        flagdate+=c;
        flagdate+="#";
        QString e;
        e.setNum(d);
        flagdate+=e;
        flagdate+="#";
        flagdate+=f;
        flagdate+="#";
        socket->write(flagdate.toLatin1());
        socket->flush();

    }

}
void pay::socket_Disconnected()
{
    //发送按键失能
    //ui->pushButton_Send->setEnabled(false);
    //修改按键文字
    //ui->pushButton_Connect->setText("连接");
    qDebug() << "Disconnected!";
}

void pay::on_pushButton_clicked()
{
    this->close();
    platformuser y(sp->returnid(),sp->returnlogname(),sp->returnpassword(),0.0);
    two z(y);
    z.show();
    z.exec();

}

void pay::on_pushButton_2_clicked()
{
    this->close();
    platformuser y(sp->returnid(),sp->returnlogname(),sp->returnpassword(),sp->returnwaitmoney());
    two z(y);
    z.show();
    z.exec();
}
