﻿#include "connectbank.h"
#include "ui_connectbank.h"
#include<QSqlError>
#include<QMessageBox>
#include"ui/two.h"
#include"QThread"
connectbank::connectbank(platformuser *s,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::connectbank)
{
    ui->setupUi(this);
   sp=new platformuser(s->returnid(),s->returnlogname(),s->returnpassword(),s->returnwaitmoney());
   socket = new QTcpSocket();
   ui->pushButton->setText("绑定");
       //连接信号槽


       QObject::connect(socket, &QTcpSocket::readyRead, this, &connectbank::socket_Read_Data);
       QObject::connect(socket, &QTcpSocket::disconnected, this, &connectbank::socket_Disconnected);
       
          
}

connectbank::~connectbank()

{

    delete ui;
}
void connectbank::socket_Read_Data()
{
    QByteArray buffer; 
   //读取缓冲区数据
    buffer = socket->readAll();
    QString str;
    if(!buffer.isEmpty())
    {
     //    str = ui->textEdit->toPlainText();
        str=tr(buffer);
        //刷新显示
    //    ui->textEdit->setText(str);
    }
    else
    {
        qDebug()<<"客户端读的是空的";
    }
    if(str=="true")//比较发过来的数据
    {
        db=QSqlDatabase::database("PlatformUsers.db");
        query=new QSqlQuery(db);
        QString sql_select;
        QString receNAME=ui->lineEdit->text();
        QString recePASS=ui->lineEdit_2->text();
        sql_select=QString("insert into banklist values(null,'%1','%2') ").arg(sp->returnid()).arg(receNAME);
        query->exec(sql_select);
       // ui->pushButton->setText("成功");
         ui->label_3->setText("成功");
       //  ui->pushButton->setEnabled(true);
       //  QThread::sleep(100);
         on_pushButton_2_clicked();
    }
    else{
       // ui->pushButton->setText("失败");
        ui->label_3->setText("失败");
         ui->pushButton->setEnabled(true);
    }
}

void connectbank::socket_Disconnected()
{
    //发送按键失能
    //ui->pushButton_Send->setEnabled(false);
    //修改按键文字
    //ui->pushButton_Connect->setText("连接");
    qDebug() << "Disconnected!";
}

void connectbank::on_pushButton_clicked()
{
    QString IP;
    int port;
    QString logname=ui->lineEdit->text();
    QString password=ui->lineEdit_2->text();
    if(!logname.isEmpty()&&!password.isEmpty())
    {
        db=QSqlDatabase::database("bank.db");
        query=new QSqlQuery(db);
        QString sql_select;
        sql_select=QString("select * from banklist where userid='%1' and cardno='%2'").arg(sp->returnid()).arg(logname);
        if(!query->exec(sql_select))
        {
            qDebug()<<query->lastError();
        }
        else
        {
            if(query->next())
            {
                QMessageBox::about(NULL, "About", "已存在");
            }
            else
            {
                //获取IP地址
                IP = "127.0.0.1";
                //获取端口号
                port = 8086;
                //取消已有的连接
                socket->abort();
                //连接服务器
                socket->connectToHost(IP, port);
                //等待连接成功
                if(!socket->waitForConnected(30000))
                {
                    qDebug() << "Connection failed!";
                    return;
                }
                else
                {
                    qDebug() << "Connect successfully!";
                    QString flagdate="*";
                    flagdate+=logname;
                    flagdate+="#";
                    flagdate+=password;
                    socket->write(flagdate.toLatin1());
                    socket->flush();
                   // ui->label_3->setText("请等待");
                    //ui->pushButton->setText("请等待");
                    ui->pushButton->setEnabled(false);
                }

            }
        }


    }
    else
    {
        ui->label_3->setText("未输入");
    }

}

void connectbank::on_pushButton_2_clicked()
{
    platformuser z(sp->returnid(),sp->returnlogname(),sp->returnpassword(),sp->returnwaitmoney());
    two y(z);
    this->close();
    y.show();
    y.exec();

}
