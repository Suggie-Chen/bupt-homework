﻿#include "_2three.h"
#include "ui__2three.h"

_2three::_2three(QString k,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::_2three)
{
    ui->setupUi(this);
    ui->label->setText("seccess");
    ui->label_3->setText(k);

}

_2three::~_2three()
{
    delete ui;
}

void _2three::on_pushButton_clicked()
{
    this->close();
}
