﻿#ifndef THREE_H
#define THREE_H
#include"bank.h"
#include <QDialog>

namespace Ui {
class three;
}

class three : public QDialog
{
    Q_OBJECT

public:
    explicit three(bank *s,QWidget *parent = 0);
    ~three();

private slots:
    void on_pushButton_clicked();

private:
    Ui::three *ui;
    bank * sp;//指针
    //数据库
    QSqlDatabase db;
    QSqlQuery *query;
};

#endif // THREE_H
