﻿#include "_2two.h"
#include "ui__2two.h"
#include<fstream>
#include <iostream>
#include<qsqlrecord>
#include<QDebug>
#include<QSqlError>
#include"_2three.h"
#include<QMessageBox>
using namespace std;
_2two::_2two(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::_2two)
{
    ui->setupUi(this);
    //显示数据库中的银行以供注册
    db=QSqlDatabase::database("bank.db");
    query=new QSqlQuery(db);
    model = new QSqlTableModel(this);
    model->setTable("bankname");
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->select(); //选取整个表的所有行
    ui->listView->setModel(model);

}

_2two::~_2two()
{
    delete ui;
}
bool isDigitSt(QString src)
{
QByteArray ba = src.toLatin1();//QString 转换为 char*
const char *s = ba.data();
while(*s && *s>='0' && *s<='9') s++;
if (*s)
{ //不是纯数字
return false;
}
else
{ //纯数字
return true;
}
}
void _2two::on_pushButton_clicked()
{

    QString a=ui->lineEdit->text();
    QString b=ui->lineEdit_3->text();
    QString c=ui->lineEdit_4->text();
   // QString d=ui->lineEdit->text();
    int row = ui->listView->currentIndex().row ();
    QAbstractItemModel *_2model = ui->listView->model();
    QModelIndex index = _2model->index(row,0);//选中行第一列的内容
    QVariant data = _2model->data(index);
    QString k=data.toString();
    ui->label_8->setText(k);
    if(row==-1)
    {
        QMessageBox::information(this,"警告","您没选择银行");
    }
    else
    {

       //填的信息正确即可注册
    if(!a.isEmpty()&&!b.isEmpty()&&!c.isEmpty()&&!k.isEmpty()&&a.size()==6&&c.size()==18)
    {
        QChar cy=c.at(17);
        QString cy1=c.mid(0,17);
        if(isDigitSt(cy1)&&((cy>='0'&&cy<='9')||(cy>='A'&&cy<='Z')))//限定账号
        {


        qDebug()<<"ok";
        QString sql_select;
        sql_select=QString("INSERT INTO banks VALUES (null,'%1','%2','%3','%4',0.0)").arg(a).arg(k).arg(b).arg(c);
        if(!query->exec(sql_select))
        {
            qDebug()<<query->lastError();
        }
        else
        {
            sql_select=QString("select *  from banks ");
            if(!query->exec(sql_select))
            {
               qDebug()<<query->lastError();
            }
            else
            {
                query->last();
                QString k=query->value(0).toString();
                _2three a(k);
                this->close();
                a.exec();
            }

        }
    }
        else
        {
            QMessageBox::information(this,"警告","您的输入错误请输入正确数据，身份证18位,密码6位");
                ui->lineEdit->clear();//清空
                ui->lineEdit_3->clear();
                ui->lineEdit_4->clear();
        }

    }
    else
    {
        QMessageBox::information(this,"警告","您的输入错误请输入正确数据，身份证18位,密码6位");
            ui->lineEdit->clear();//清空
            ui->lineEdit_3->clear();
            ui->lineEdit_4->clear();
    }

}
}
