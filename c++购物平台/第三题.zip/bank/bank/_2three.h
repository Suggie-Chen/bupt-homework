﻿#ifndef _2THREE_H
#define _2THREE_H

#include <QDialog>

namespace Ui {
class _2three;
}

class _2three : public QDialog
{
    Q_OBJECT

public:
    explicit _2three(QString k ,QWidget *parent = 0);
    ~_2three();

private slots:
    void on_pushButton_clicked();

private:
    Ui::_2three *ui;
};

#endif // _2THREE_H
