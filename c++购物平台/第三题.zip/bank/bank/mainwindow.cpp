﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"two.h"
#include<QDebug>
#include<qsqlerror.h>
#include"_2two.h"
#include"QMessageBox"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    server = new QTcpServer();
    //连接信号槽
    server->listen(QHostAddress::Any, 8086);
    connect(server,&QTcpServer::newConnection,this,&MainWindow::server_New_Connect);


}

MainWindow::~MainWindow()
{
    server->close();
    server->deleteLater();
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{   //登陆
    QString m=ui->lineEdit->text();
    int m1=m.toInt();
    QString n=ui->lineEdit_2->text();
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    //查询数据库
    db=QSqlDatabase::database("bank.db");
    query=new QSqlQuery(db);
    QString sql_select;
    sql_select=QString("select * from banks ");
    if(!query->exec(sql_select))
    {
        qDebug()<<query->lastError();
    }
    else
    {
       bool flag11=true;
       while(query->next())
       {
           if(m1==query->value(0).toInt()&&n==query->value(1).toString())
           {
               int a=query->value(0).toInt();
               QString b=query->value(1).toString();
               QString c=query->value(2).toString();
               QString d=query->value(3).toString();
               QString e =query->value(4).toString();
               double f=query->value(5).toDouble();
               sp=new bank(a,b,c,d,e,f);
               two k(sp);
               //成功登陆界面
               k.show();
               k.exec();
               flag11=false;
               break;
           }
       }
       if(flag11==true)
       {
           QMessageBox::information(this,"警告","账号或密码错误");
       }

    }
}

void MainWindow::on_pushButton_2_clicked()
{
       _2two k;
       k.exec();
}
void MainWindow::server_New_Connect()
{
    //获取客户端连接
    socket = server->nextPendingConnection();
    //连接QTcpSocket的信号槽，以读取新数据
    QObject::connect(socket, &QTcpSocket::readyRead, this, &MainWindow::socket_Read_Data);
    QObject::connect(socket, &QTcpSocket::disconnected, this, &MainWindow::socket_Disconnected);
    //发送按键使能
   // ui->pushButton_Send->setEnabled(true);
    qDebug() << "A Client connect!";
}

void MainWindow::socket_Read_Data()
{
    QByteArray buffer;
    //读取缓冲区数据
    buffer = socket->readAll();
    QString str;
    if(!buffer.isEmpty())
    {
         //str = ui->textEdit->toPlainText();
        str=tr(buffer);
        //刷新显示
    //    ui->textEdit->setText(str);

    }
    else
    {
        qDebug()<<"服务端为空";
    }
     qDebug()<<"服务端"<<str;
    //qDebug()<<"服务端"<<str.at(0);
    if(str.at(0)=='*')//绑定银行卡
    {
            QString receivestr=str.mid(1);
            QStringList K=receivestr.split("#");

            QString receNAME=K[0];
            QString recePASS=K[1];
            qDebug()<<"绑定银行"<<receNAME<<" "<<recePASS;
            db=QSqlDatabase::database("bank.db");
            query=new QSqlQuery(db);
            QString sql_select;
            sql_select=QString("select * from banks where id='%1' and password='%2' ").arg(receNAME).arg(recePASS);
            if(!query->exec(sql_select))
            {
                qDebug()<<query->lastError();
                str="";
            }
            else
            {
                if(!query->next())
                {
                    socket->write("false");//成功
                    socket->flush();
                    str="";
                }
                else
                {
                    socket->write("true");//失败
                    socket->flush();
                    str="";
                }
            }

    }
    else
    {
        if(str.at(0)=='@')//支付时
        {
            QString receivestr=str.mid(1);
            QStringList K=receivestr.split("#");

            QString receNO=K[0];
            QString recePAY=K[1];
            QString recePA=K[2];
            qDebug()<<"需要支付"<<receNO<<" "<<recePAY;
            db=QSqlDatabase::database("bank.db");
            query=new QSqlQuery(db);
            int receNO1=receNO.toInt();
            qDebug()<<"账号"<<receNO1;
            qDebug()<<"密码"<<recePA;
            QString sql_select;
            sql_select=QString("select * from banks where id='%1' and password='%2'").arg(receNO1).arg(recePA);
            //与银行存款比较
            if(!query->exec(sql_select))
            {
                qDebug()<<query->lastError();
            }
            else
            {
                if(query->next())
                {
                    double balance= query->value(5).toDouble();
                    qDebug()<<"余钱"<<balance;
                    double pay=recePAY.toDouble();//接收到的数据
                   //比较付款与余钱
                    if(balance<pay)
                    {

                         qDebug()<<"余钱不够";
                        socket->write("0");
                        socket->flush();
                        receNO="";
                        recePAY="";
                        recePA="";
                        str="";
                    }
                    else
                    {
                        sql_select=QString("update banks set money='%1' where id='%2' ").arg(balance-pay).arg(receNO1);
                        if(!query->exec(sql_select))
                        {
                            qDebug()<<query->lastError();
                        }
                        socket->write("1");
                        socket->flush();
                        receNO="";
                        recePAY="";
                        recePA="";
                        str="";
                    }
                }
                else
                {
                    //发回错误
                    qDebug()<<"没打开数据库";
                    socket->write("2");
                    socket->flush();
                    receNO="";
                    recePAY="";
                    recePA="";
                    str="";
                }

            }
        }
    }

}

void MainWindow::socket_Disconnected()
{
    //发送按键失能
  //  ui->pushButton_Send->setEnabled(false);
    qDebug() << "Disconnected!";
}
