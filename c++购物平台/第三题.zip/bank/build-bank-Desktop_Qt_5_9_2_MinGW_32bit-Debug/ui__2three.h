/********************************************************************************
** Form generated from reading UI file '_2three.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI__2THREE_H
#define UI__2THREE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui__2three
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QDialog *_2three)
    {
        if (_2three->objectName().isEmpty())
            _2three->setObjectName(QStringLiteral("_2three"));
        _2three->resize(400, 300);
        label = new QLabel(_2three);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(160, 70, 72, 15));
        pushButton = new QPushButton(_2three);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(150, 240, 93, 28));
        horizontalLayoutWidget = new QWidget(_2three);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(120, 150, 160, 41));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(horizontalLayoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        label_3 = new QLabel(horizontalLayoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout->addWidget(label_3);


        retranslateUi(_2three);

        QMetaObject::connectSlotsByName(_2three);
    } // setupUi

    void retranslateUi(QDialog *_2three)
    {
        _2three->setWindowTitle(QApplication::translate("_2three", "Dialog", Q_NULLPTR));
        label->setText(QString());
        pushButton->setText(QApplication::translate("_2three", "\350\277\224\345\233\236", Q_NULLPTR));
        label_2->setText(QApplication::translate("_2three", "\351\223\266\350\241\214\350\264\246\345\217\267", Q_NULLPTR));
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class _2three: public Ui__2three {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI__2THREE_H
