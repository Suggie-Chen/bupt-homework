/********************************************************************************
** Form generated from reading UI file 'four.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FOUR_H
#define UI_FOUR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_four
{
public:
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QDialog *four)
    {
        if (four->objectName().isEmpty())
            four->setObjectName(QStringLiteral("four"));
        four->resize(231, 175);
        pushButton = new QPushButton(four);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(70, 130, 93, 28));
        label = new QLabel(four);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(80, 60, 72, 15));

        retranslateUi(four);

        QMetaObject::connectSlotsByName(four);
    } // setupUi

    void retranslateUi(QDialog *four)
    {
        four->setWindowTitle(QApplication::translate("four", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("four", "\350\277\224\345\233\236", Q_NULLPTR));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class four: public Ui_four {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FOUR_H
