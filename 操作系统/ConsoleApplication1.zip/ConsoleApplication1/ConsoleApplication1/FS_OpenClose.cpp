#include"FS_HEAD.h"
/*---------------------��ʼ�����̵���Ϣ�����Ƴ�ʼ��superblock��-----------------------*/

void init()
{
		blockSize = BLOCK_SIZE;
		blockNum = BLOCK_NUM;
		inodeNum = INODE_NUM;
		blockBitmap = (  int*)malloc((blockNum + 1) * sizeof(  int));
		//blockBitmap[1] = '0';
		//printf("%c", blockBitmap[1]);
		inodeBitmap	= (  int*)malloc((blockNum + 1) * sizeof( int));
		superBlockSize = sizeof(SuperBlock);
		blockBitmapSize = BLOCK_NUM*sizeof(int);
		inodeBitmapSize = BLOCK_NUM*sizeof(int);
		inodeSize = sizeof(Inode);
		fcbSize = sizeof(Fcb);
		itemSize = sizeof(  int);
		//SuperBlockOffset
		BlockBitmapOffset = superBlockSize;
		InodeBitmapOffset = BlockBitmapOffset + blockBitmapSize;
		IOffset = InodeBitmapOffset + inodeBitmapSize;
		BOffset = IOffset +( sizeof(Inode))*blockNum;
		//FCB
		HideLink = (FcbLink)malloc(sizeof(FcbLinkNode));
		HideLinkFirst = (FcbLink)malloc(sizeof(FcbLinkNode));
		CurrentLink= (FcbLink)malloc(sizeof(FcbLinkNode));
		CurrentLink->next = NULL;
		//record(init_record);//��־
		
}
/*---------------------����TXT�ĸ�����ĺ���-----------------------*/
void updateSuperBlock(SuperBlock superblock)//����superblock
{
	fseek(fp, 0, SEEK_SET);
	fwrite(&superblock, superBlockSize, 1, fp);
}

void createBlockBitmap(  int* bitmap)//����blockBitmap(createsystem)
{
	fseek(fp, BlockBitmapOffset, SEEK_SET);
	fwrite(bitmap, sizeof(int), BLOCK_NUM, fp);
}
	
void createInodeBitmap(  int* bitmap)//����InodeBitmap(createsystem)
{
	fseek(fp, InodeBitmapOffset, SEEK_SET);
	fwrite(bitmap, sizeof(int), BLOCK_NUM, fp);
}
void updateInode(Inode inode)//����Inode�飨�ڵ���Ϣ�飩
{
	//printf("sizeof%d", sizeof(Inode));
	fseek(fp,IOffset+inode.id*sizeof(Inode), SEEK_SET);
	fwrite(&inode, sizeof(Inode), 1, fp);
}

void Del_updateInodeBitmap(  int* bitmap,   int index)//�ļ��У�
{
	inodeBitmap[index] = 0;
	createBlockBitmap(blockBitmap);//����TXT
}

void Cre_updateInodeBitmap(  int* bitmap,   int index)//�ļ��У�
{
	inodeBitmap[index] = 1;
	createBlockBitmap(blockBitmap);//����TXT
}

/*---------------------���û��FS_TXT�ļ��򴴽������Դ����Ľ���TXT���г�ʼ��-----------------------*/
void FS_CreateSystem()
{
	if ((fp = fopen("FS_TXT", "w+")) == NULL)
	{
		printf("error 000:can't create a new disk");
		system("pause");
	}
	else
	{
		//��ʼ��superblock
		SuperBlocks.blockNum = BLOCK_NUM;
		SuperBlocks.blockSize = BLOCK_SIZE;
		SuperBlocks.blockFree = BLOCK_NUM-1;//��һ���ڵ���Ϊ���ڵ㡣
		SuperBlocks.inodeNum = 1;
		updateSuperBlock(SuperBlocks);

		//��ʼ������λͼ
		inodeBitmap[0] = 1;
		blockBitmap[0] = 0;

		

		for (int i = 1; i < BLOCK_NUM; i++)//��ʼ����Ŀ�
		{
			inodeBitmap[i] = 0;
			blockBitmap[i] = 0;
		}

		createBlockBitmap(blockBitmap);//����TXT
		createInodeBitmap(inodeBitmap);//����TXT
		int len = 0;
		len += (inodeSize + blockSize) * blockNum;//�ڵ��С�Ϳ��С(����TXT)
		for ( int i = 0; i < len; i++)
		{
			fputc(0, fp);
		}
		//init root dir
		//set root inode info
		CurrentInode.id = 0;
		strcpy(CurrentInode.name, "/");
		CurrentInode.isDir = '1';
		CurrentInode.parent = -1;//����˵���ڵ���inodeSize
		CurrentInode.length = 0;
		CurrentInode.type = 11;
		time(&(CurrentInode.time));
		for (int i = 0; i < MAX_FILE_BLOCK_NUM; i++)
		{
			CurrentInode.addr[i] = -1;
		}
		//write root inode 
		updateInode(CurrentInode);//����ǰ�Ľڵ�д��txt
		fflush(fp);
		
	}
}

/*---------------------�����FS_TXT�ļ��򴴽�����ȡ����-----------------------*/
void getSuperBlock(SuperBlock* pSuper)//��ȡSuperblock
{
	fseek(fp, 0, SEEK_SET);
	fread(pSuper, superBlockSize, 1, fp);
}
void getBlockBitmap(  int* bitmap)//��ȡ��λͼ
{
	fseek(fp, BlockBitmapOffset, SEEK_SET);
	fread(bitmap, blockBitmapSize, 1, fp);
}
void getInodeBitmap(  int* bitmap)//��ȡ�ڵ�λͼ
{
	fseek(fp, InodeBitmapOffset, SEEK_SET);
	fread(bitmap, inodeBitmapSize, 1, fp);
}

void getInode(PInode pInode,   int id)//��ȡһ���ڵ�
{ 
	//pInode->blockId = (int*)malloc(sizeof(int) *MAX_FILE_BLOCK_NUM);
	fseek(fp, IOffset+id*inodeSize, SEEK_SET);
	fread(pInode, inodeSize, 1, fp);
}

void FS_OpenSystem()//�����ϵͳ
{
	init();//��ʼ��ȫ�ֱ���

	if ((fp = fopen("FS_TXT", "rb+"))== NULL)
	{
		FS_CreateSystem();
		
	}
	else
	{	
		//record(init_record);//��־
		getSuperBlock(&SuperBlocks);//���superBlock
		getBlockBitmap(blockBitmap);//���blockbitmap
		getInodeBitmap(inodeBitmap);//���inodebitmap
		getInode(&CurrentInode, 0);//��ó�ʼ�ĸ��ڵ�
		/*
		--------------------------------------
		���Ի��inodebitmap
		for (int k = 0; k < BLOCK_NUM; k++)
		{
			printf("k:%d=%d\n", k, inodeBitmap[k]);
		}
		=======================================
		*/
	
		/*
		--------------------------------------
		���Ի��blockbitmap
		for (int k = 0; k < BLOCK_NUM; k++)
		{
			printf("k:%d=%d\n", k,blockBitmap[k]);
		}
		======================================
		*/
		
		getDirFcblink(CurrentLink, CurrentInode);//��ȡ��ʼ��fcb��

		/*
		--------------------------------------
		���Ի�ó�ʼFCB��������
		FcbLink Z = CurrentLink;
		for (; Z!=NULL; Z=Z->next)
		{
			printf("%s\t", Z->fcb.name );system("pause");
		}
		======================================
		*/

		getFcblink();//��ȡһ��ȫ��FCB����
		record(open_system_record);//��־��¼
		record(begin);

		//child("z1");
		FS_ls();
		/*FcbLink ka = CurrentLink;
		FS_CreateFile((char*)"z1", '1', 11);
		FcbLink k = HideLinkFirst;
		FS_CreateFile((char*)"z2", '0', 11);
		write((char*)"z2");
		printf("%s",read((char*)"z2", 0));
		//FS_Delete("z2");
		//child("z1");
		FS_CreateFile((char*)"m2", '0', 11);
		FS_Delete((char*)"m2");*/
		//FS_CreateFile("m1", '0', 11);
		//FS_ls();
		/*
		--------------------------------------
		���Ի��ȫ�ֳ�ʼFCB��������
		FcbLink Zi =HideLinkFirst;
		for (; Zi!=NULL; Zi=Zi->next)
		{
			printf("%s\t", Zi->fcb.name );
			system("pause");
		}
		======================================


		*/
		//FS_CreateFile("k1", '0', 11);
		//FS_Delete("k1");
		//FS_CreateFile("m1", '1', 11);
		//FS_Delete("m1");
		//FS_CreateFile("k2", '0', 11);
		//chmod("k1", 11);
		//FS_CreateFile("k2", '0', 10);
		//FS_CreateFile("k3", '0', 10);
		//FS_CreateFile("m2", '1', 10);
		//FS_CreateFile("m2", '1', 10);
		//FS_CreateFile("m3", '1', 10);

		
		//FS_Delete("k1");
		//FS_Delete("m1");
		//getDirFcblink(CurrentLink, CurrentInode);
		//getFcblink();
		//record(open_system_record);//��־��¼
		
	}
	
}