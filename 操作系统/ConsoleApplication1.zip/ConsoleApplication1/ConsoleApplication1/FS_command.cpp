#include"FS_HEAD.h"
#include"PROCESS.h"
void face();
void commandAnalysis()//������ִ��������ַ�����0Ϊִ��ʧ�ܣ�1Ϊִ�гɹ�

{

	face();

	int mode = 0;
	int c;
	while ((c = getchar()) != '\n' && c != EOF);
	char choice = getchar();

	char buf1[100];

	char di ;

	while (choice != '0')

	{

		switch (choice)

		{

		case '1':

		{

			cout << "Please imput your filename ,filedir��0=file,1=dir�� and file attributes:(rw=11,_r_w=0,r_w=10,_rw=1)or (exit=!)" << endl;

			cin >> buf1;
			if (!strcmp(buf1, "!"))
			{
				system("CLS");
				printf("�˳�\n");
				face();
				FS_ls();
				int c;
				while ((c = getchar()) != '\n' && c != EOF);
				choice = getchar();
				continue;
			}
			cin >> di;

			cin>> mode;
			
			if (di == '0' || di == '1')
			{
				if (cin.good() && (mode == 0 || mode == 11 || mode == 10 || mode == 1))
				{
					FS_CreateFile(buf1, di, mode);
				}
				else
				{
					printf("�����������\n");
					cin.clear();
				}
				
			}
			else
			{

				printf("�������\n");
				cin.clear();
				
			}

			

			break;

		}

		case '2':

		{

			cout << "Please imput your filename:" << endl;

			cin >> buf1;
			if (!strcmp(buf1, "!"))
			{
				system("CLS");
				printf("�˳�\n");
				face();
				FS_ls();
				int c;
				while ((c = getchar()) != '\n' && c != EOF);
				choice = getchar();
				continue;
			}

			FS_Delete(buf1);

			break;

		}

		case '3':

		{

			cout << "Please imput your child dirname:" << endl;

			cin >> buf1;
			if (!strcmp(buf1, "!"))
			{
				system("CLS");
				printf("�˳�\n");
				face();
				FS_ls();
				int c;
				while ((c = getchar()) != '\n' && c != EOF);
				choice = getchar();
				continue;
			}

			child(buf1);

			break;

		}

		case '4':

		{

			//cout << "Please imput your father dirname:" << endl;

			//cin >> buf1;

			father(NULL);

			break;

		}

		case '5':

		{

			cout << "Please imput your filename and blocknum:" << endl;

			cin >> buf1;
			if (!strcmp(buf1,"!"))
			{
				system("CLS");
				printf("�˳�\n");
				face();
				FS_ls();
				int c;
				while ((c = getchar()) != '\n' && c != EOF);
				choice = getchar();
				continue;
			}

			cin >> mode;

			printf("%s", read(buf1, mode));

			break;

		}

		case '6':

		{

			cout << "Please imput your filename:" << endl;

			cin >> buf1;
			if (!strcmp(buf1, "!"))
			{
				system("CLS");
				printf("�˳�\n");
				face();
				FS_ls();
				int c;
				while ((c = getchar()) != '\n' && c != EOF);
				choice = getchar();
				continue;
			}
			int c;
			while ((c = getchar()) != '\n' && c != EOF);
			write(buf1);
			record(open_system_record);
			break;

		}

		case '8':

		{

			FS_ls();

			break;

		}

		case '7':

		{

			cout << "Please imput your filename and attributes(rw=11,_r_w=0,r_w=10,_rw=1)or (exit=!):" << endl;


			cin >> buf1;
			if (!strcmp(buf1, "!"))
			{
				system("CLS");
				printf("�˳�\n");
				face();
				FS_ls();
				int c;
				while ((c = getchar()) != '\n' && c != EOF);
				choice = getchar();
				continue;
			}

			cin >> mode;
			
			if (cin.good()&&(mode == 0 || mode == 11 || mode == 10 || mode == 1))
			{
				chmod(buf1, mode);
			}
			else
			{
				printf("�����������\n");
				cin.clear();
			}
			
			break;

		}

		default:

		{

			cout << "ERROR OPERATION!" << endl;

			break;

		}

		}

		system("pause");

		system("CLS");

		int c;
		while ((c = getchar()) != '\n' && c != EOF);
		face();
		FS_ls();

		cin >> choice;

	}
	strcpy(print_control, "*");
	return;

}



void face()

{

	cout << "++++++++++++++++++++++++++ WELCOME! ++++++++++++++++++++++++++++" << endl;

	cout << "������������������������FILE_SYSTERM��������������������������" << endl;

	cout << "|  1.Create_File                                2.Delete_File  |" << endl;

	cout << "|  3.Child_File                                 4.Father_File  |" << endl;

	cout << "|  5.Read_File                                  6.Write_File   |" << endl;

	cout << "|  7.Change_Attributes                          8.Show_Files   |" << endl;

	cout << "|  0.Exit_Systerm                                              |" << endl;

	cout << "|                  You can choose to perform any operations!   |" << endl;

	cout << "����������������������������������������������������������������" << endl;

}
