#include"FS_HEAD.h"

//��ʾ��ǰĿ¼�µ������ļ���Ϣ
void FS_ls()
{
	if (CurrentLink->fcb.length == 0)
	{
		printf("Ŀ¼:%sΪ��\n",CurrentLink->fcb.name);
	}
	else
	{
		FcbLink link = CurrentLink->next;
		printf("Ŀ¼��%s\n", CurrentInode.name);
		//ͨ��FCB���ҽڵ�			 	
		while (link != NULL)
		{
			showFileDetail(link);
			link = link->next;
		}
	}
	
	
}

//��ȡһ���ڵ�,ͨ��id���
/*void getInode(PInode pInode,   int id)
{
	//pInode->blockId = (char*)malloc(sizeof(char) *MAX_FILE_BLOCK_NUM);
	if (pInode == NULL || fp == NULL)
	{
		return;
	}
	fseek(fp, IOffset + id*inodeSize, SEEK_SET);
	fread(pInode, sizeof(Inode), 1, fp);

	seek(fp, IOffset + id*inodeSize + sizeof(Inode), SEEK_SET);
	for (int i = 0; i < MAX_FILE_BLOCK_NUM; i++)
	{
	pInode->addr[i]=fgetc(fp);
	}
}*/

//�ļ���Ԕ����Ϣ
void showFileDetail(FcbLink pInode)
{
	if (pInode == NULL)
		return;
	//format output
	if (pInode->fcb.isDir == '1')
	{
		printf("dir�� %5s\t\t", pInode->fcb.name);
	}
	else if(pInode->fcb.isDir == '0')
	{
		printf("file��%5s\t\t",pInode->fcb.name);
	}
	if (pInode->fcb.type == 11)
	{
		printf("rw\t");
	}
	else if (pInode->fcb.type == 10)
	{
		printf("r-\t");
	}
	else if (pInode->fcb.type == 00)
	{
		printf( "--\t");
	}
	else if (pInode->fcb.type == 01)
	{
		printf("-w\t");
	}
	printf(" %5d\t", pInode->fcb.length);
	//printf(" %.12s", 4 + ctime(&(pInode->fcb.time)));
    //printf(" %s", pInode->fcb.name);
	printf("\n");
}

//___________________________________________________________________Ŀ¼____________________________________________________________________________________//
//������Ŀ¼/�ļ�
int child(char* name)
{
	if (name == NULL)
	{
		printf("invalid file name!,or the file has existed\n");
		return 0;
	}
	if (strcmp(name, "") == 0)
	{
		printf("The name is empty!\n");
		return 0;
	}
	
//	printf("cd from %s to child %s\n", CurrentInode.name, name);

	//�������ļ�/Ŀ¼
	  int	id = findChildInode(CurrentLink, name);//�����ļ�
	if (id > 0)
	{
		Inode yyk;
		getInode(&yyk, id);
		if (yyk.isDir == '0')
		{
			printf("%s is a file", name);
			return 0;
		}
		if (yyk.type == 00 || yyk.type == 01)
		{
			printf("%s can't read", name);
			return 0;
		}
		printf("cd from %s to child %s\n", CurrentInode.name, name);
		getInode(&CurrentInode, id);
		getDirFcblink(CurrentLink, CurrentInode);//�Ե�ǰ�ڵ�Ϊ�׽ڵ㽨��Ŀ¼��
		CurrentPath.append("/");
		CurrentPath.append(name);//����·��
		return 1;
	}
	else
	{
		printf("no such directory:%s\n", name);
		return 0;
	}
}
//���ظ�Ŀ¼
int father(char* name)
{
	
	

	//�ص���Ŀ¼
	  int id = CurrentInode.parent;
	if (CurrentInode.id > 0)//��Ŀ¼����
		{
			getInode(&CurrentInode, id); //��ȡ���ڵ�
			getDirFcblink(CurrentLink, CurrentInode); //�Ե�ǰ�ڵ�Ϊ�׽ڵ㽨��Ŀ¼��
			int pos = CurrentPath.rfind('/', CurrentPath.length() - 2);//�ҵ����һ��ƥ�䡮/����λ��
			CurrentPath.erase(pos + 1, CurrentPath.length() - 1 - pos);//�h����·��
			return 1;
			
		}
	else
	{
		printf("no such file or directory:%s\n", name);
		return 0;
	}
		
}

//���½���Ŀ¼����Ϣ��
void getDirFcblink(FcbLink curLink, Inode inode)
{
	if (curLink != NULL)
	{
		//releaseFcbLink(curLink);//�ͷŵ�ǰĿ¼��
	}

	//Ŀ¼�����ڵ�
	//printf("start read dir self inode\n");
	//FcbLinkNode curLink ;
	getFcbLinkNode(curLink, inode);//�Ե�ǰ�ڵ㽨���µ�Ŀ¼��
	

	if (inode.length <= 0 || inode.isDir =='0')  //Ŀ¼û�����ļ�/���ļ�
		return;

	//��Ŀ¼�������������ļ�/Ŀ¼�ڵ�
	int i;
	int id;
	Inode fileInode;
	FcbLink pNode=NULL;
	pNode = (FcbLink)malloc(sizeof(FcbLinkNode));
	FcbLink link = curLink;
	  int len = inode.length;//���ļ�����Ŀ¼��
	//����10��ֱ������
	for (i = 0; i < MAX_FILE_BLOCK_NUM; i++)
	{
		id = inode.addr[i];
		if (id > 0)
		{
			//���������µ��ļ�id�ڵ�����
			//printf("%s\t", link->fcb.name);
			getInode(&fileInode, id);
 			getFcbLinkNode(pNode, fileInode); //���ӽڵ�
			//ʵ�廯��������ֵ
			link->next = (FcbLink)malloc(sizeof(FcbLinkNode));
			link->next->fcb.id = pNode->fcb.id;
			strcpy(link->next->fcb.name, pNode->fcb.name);
			link->next->fcb.isDir = pNode->fcb.isDir;
			for (int t = 0; t< MAX_FILE_BLOCK_NUM; t++)
				link->next->fcb.addr[t] = pNode->fcb.addr[t];
			link->next->fcb.length = pNode->fcb.length;
			link->next->fcb.parent = pNode->fcb.parent;
			link->next->fcb.type = pNode->fcb.type;	
			link->next->next = NULL;
			link = link->next;
			
			//printf("%s\t", link->fcb.name);
			//if (link != curLink)
			//	printf("123");
			//printf("read dir item inode: id=%d, name=%s, index=%d\n", fileItem, fileInode.name, index);
		}
	}
	//printf("%s\t", curLink->fcb.name);
	//printf("%s\t", curLink->next->fcb.name);
	//printf("%s\t", curLink->next->next->fcb.name);
}



//��ղ��ͷ�Ŀ¼��Ϣ��
void releaseFcbLink(FcbLink curLink)//(����)
{
	FcbLink link = curLink;
	FcbLink tmp;
	while (link->next != NULL)
	{
		tmp = link->next;
		delete link;
		link = tmp;
	}
	curLink = NULL;
}
//Ŀ¼��Ϣ�����ӽڵ�
void getFcbLinkNode(FcbLink pNode, Inode inode)
{
	if (pNode == NULL)
	{
		return;
	}
	pNode->fcb.id = inode.id;
	strcpy(pNode->fcb.name, inode.name);
	pNode->fcb.isDir = inode.isDir;
	for (int i = 0; i < MAX_FILE_BLOCK_NUM; i++)
		pNode->fcb.addr[i] = inode.addr[i];
	pNode->fcb.length = inode.length;
	pNode->fcb.parent = inode.parent;
	pNode->fcb.type = inode.type;
	pNode->next = NULL;
}
//Ŀ¼��Ϣ������һ���ڵ�
void appendFcbLinkNode1(FcbLink curLink, Inode inode)
{
	if (curLink == NULL || inode.id <= 0)//�������Ӹ��ڵ�
	{
		return;
	}
	FcbLink link = curLink;
	while (link->next != NULL)
	{
		link = link->next;
	}
	//FcbLink pNode = new FcbLinkNode();
	//getFcbLinkNode(pNode, inode);
	link->next = (FcbLink)malloc(sizeof(FcbLinkNode));
	link->next->fcb.id = inode.id;
	strcpy(link->next->fcb.name, inode.name);
	link->next->fcb.isDir = inode.isDir;
	for (int i = 0; i < MAX_FILE_BLOCK_NUM; i++)
		link->next->fcb.addr[i] = inode.addr[i];
	link->next->fcb.length = inode.length;
	link->next->fcb.parent = inode.parent;
	link->next->fcb.type = inode.type;
	link->next->next = NULL;
}

//Ŀ¼��Ϣ��ɾ��һ���ڵ㣬����ɾ�����ڵ�
void removeFcbLinkNode(FcbLink curLink, Inode inode)
{
	if (curLink == NULL || inode.id <= 0)
	{
		printf("You can't remove the root!\n");
		return;
	}
	FcbLink link = curLink->next;
	FcbLink last = curLink;
	while (link != NULL)
	{
		if (link->fcb.id == inode.id)//id
		{
			last->next = link->next;
			free(link);
			break;
		}
		last = link;
		link = link->next;
	}
}

// Ŀ¼��Ϣ��ɾ��һ���ڵ㣬����ɾ�����ڵ㣬���������Ƴ�
void removeFcbLinkNode(FcbLink curLink, char* name)
{
	if (curLink == NULL || name == NULL)
	{
		return;
	}
	FcbLink link = curLink->next;
	FcbLink last = curLink;
	while (link != NULL)
	{
		if (strcmp(link->fcb.name, name) == 0)//name
		{
			last->next = link->next;
			delete link;
			break;
		}
		last = link;
		link = link->next;
	}
}